export default function About() {
  return (
    <section id="about" className="py-20 md:py-28 bg-farm-cream">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-farm-green font-semibold text-sm uppercase tracking-wider mb-2">
              Our Story
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-farm-brown mb-6 font-display">
              Three Generations of Farming Excellence
            </h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              Green Valley Farm began in 1987 when our grandparents planted their first
              vegetable rows on 40 acres of fertile land. What started as a small market
              garden has grown into a thriving, diversified farm that still stays true
              to the same values: respect for the land, honest work, and food that tastes
              the way nature intended.
            </p>
            <p className="text-gray-700 leading-relaxed mb-6">
              Today we practice regenerative agriculture — building soil health, rotating
              crops, and raising animals on pasture. Every egg, every tomato, and every
              jar of honey comes with a story of care and stewardship.
            </p>
            <div className="flex flex-wrap gap-6">
              <div>
                <p className="text-3xl font-bold text-farm-green">40+</p>
                <p className="text-sm text-gray-600">Acres of farmland</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-farm-green">35+</p>
                <p className="text-sm text-gray-600">Years of experience</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-farm-green">100%</p>
                <p className="text-sm text-gray-600">Organic practices</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-xl bg-gradient-to-br from-farm-light to-farm-green flex items-center justify-center">
              <div className="text-center text-white p-8">
                <span className="text-6xl mb-4 block">🏡</span>
                <p className="text-lg font-medium">Family Farm</p>
                <p className="text-sm opacity-80 mt-1">Since 1987</p>
              </div>
            </div>
            <div className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-lg p-4 max-w-[180px]">
              <p className="text-farm-gold text-2xl font-bold">🌱</p>
              <p className="text-sm font-semibold text-farm-brown">Regenerative</p>
              <p className="text-xs text-gray-500">Soil-first farming</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
