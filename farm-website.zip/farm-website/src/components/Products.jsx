const products = [
  {
    icon: '🥬',
    title: 'Organic Vegetables',
    description: 'Seasonal greens, tomatoes, root crops, and more — harvested at peak flavor and delivered fresh.',
    tag: 'Seasonal',
  },
  {
    icon: '🥚',
    title: 'Free-Range Eggs',
    description: 'Pasture-raised hens that roam freely produce eggs with rich yolks and exceptional taste.',
    tag: 'Daily',
  },
  {
    icon: '🥩',
    title: 'Grass-Fed Meats',
    description: 'Beef and lamb raised on open pasture without antibiotics or growth hormones.',
    tag: 'Premium',
  },
  {
    icon: '🍯',
    title: 'Raw Honey',
    description: 'Local wildflower honey from our own hives — pure, unfiltered, and full of flavor.',
    tag: 'Limited',
  },
  {
    icon: '🧀',
    title: 'Artisan Dairy',
    description: 'Fresh milk, butter, and cheeses from our grass-fed dairy cows.',
    tag: 'Weekly',
  },
  {
    icon: '🌻',
    title: 'Cut Flowers',
    description: 'Seasonal bouquets and dried arrangements grown right here on the farm.',
    tag: 'Seasonal',
  },
]

export default function Products() {
  return (
    <section id="products" className="py-20 md:py-28 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-14">
          <p className="text-farm-green font-semibold text-sm uppercase tracking-wider mb-2">
            What We Grow
          </p>
          <h2 className="text-3xl md:text-4xl font-bold text-farm-brown mb-4 font-display">
            Farm-Fresh Products
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            From the field to your kitchen — everything we offer is raised or grown
            with regenerative practices and zero synthetic chemicals.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <article
              key={product.title}
              className="group bg-farm-cream rounded-2xl p-6 border border-transparent hover:border-farm-light/30 hover:shadow-lg transition-all duration-300"
            >
              <div className="flex items-start justify-between mb-4">
                <span className="text-4xl">{product.icon}</span>
                <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-farm-green/10 text-farm-green">
                  {product.tag}
                </span>
              </div>
              <h3 className="text-lg font-semibold text-farm-brown mb-2 group-hover:text-farm-green transition-colors">
                {product.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {product.description}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
