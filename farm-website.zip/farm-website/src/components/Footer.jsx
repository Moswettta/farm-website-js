export default function Footer() {
  return (
    <footer className="bg-farm-brown text-white/90 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🌾</span>
            <span className="font-bold text-lg">Green Valley Farm</span>
          </div>

          <nav className="flex flex-wrap justify-center gap-6 text-sm">
            <a href="#home" className="hover:text-farm-gold transition-colors">Home</a>
            <a href="#about" className="hover:text-farm-gold transition-colors">About</a>
            <a href="#products" className="hover:text-farm-gold transition-colors">Products</a>
            <a href="#contact" className="hover:text-farm-gold transition-colors">Contact</a>
          </nav>

          <p className="text-sm text-white/60">
            © {new Date().getFullYear()} Green Valley Farm. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
