const testimonials = [
  {
    quote: "The eggs from Green Valley have the richest yolks I've ever tasted. Once you go pasture-raised, there's no going back.",
    name: 'Sarah M.',
    role: 'Weekly CSA member',
  },
  {
    quote: "We visit the farm every fall with our kids. Seeing where food comes from has changed how our whole family eats.",
    name: 'James & Lisa T.',
    role: 'Family visitors',
  },
  {
    quote: "Their honey is pure magic. I use it in everything — tea, baking, even just by the spoonful. Support this farm!",
    name: 'Elena R.',
    role: 'Local chef',
  },
]

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-20 md:py-28 bg-farm-cream">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-14">
          <p className="text-farm-green font-semibold text-sm uppercase tracking-wider mb-2">
            Community Love
          </p>
          <h2 className="text-3xl md:text-4xl font-bold text-farm-brown mb-4 font-display">
            What Our Neighbors Say
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <blockquote
              key={t.name}
              className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 flex flex-col"
            >
              <div className="text-farm-gold text-2xl mb-3">“</div>
              <p className="text-gray-700 leading-relaxed flex-1 mb-6">{t.quote}</p>
              <footer>
                <p className="font-semibold text-farm-brown">{t.name}</p>
                <p className="text-sm text-gray-500">{t.role}</p>
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  )
}
